Terminology:

Users:
	Owner:
		same as Administrator.
	
	Manager:
		same as Shop/Store manager.
	
	Worker:
		same as Marketing Employee.
	
	Customer:
		same as User.
	
	Support:
		same as Customer service employee.
	
	Not implemented:
		Shop employee - not needed.

Products:
	Flowers or bouquets or flower pots

ProductManager:
	Stores the information about available products.
	e.g., which categories.

AccountManager:
	Handles Invoices of previous orders.

CartItem:
	A single Product with chosen amount to buy

OrderManager:
	Handles current order / cart items.

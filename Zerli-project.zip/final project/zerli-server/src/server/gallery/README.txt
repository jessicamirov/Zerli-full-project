Stores flower images.
Required for initialization of database.
